<?php

if (!defined('ABSPATH')) {
    exit;
}

do_action('sikshya_before_single_question');
?>

<div class="sikshya-quiz-question sikshya-quiz-question-loop-wrap">