<?php

if (!defined('ABSPATH')) {
    exit;
}
?>
    </div>
<?php
do_action('sikshya_after_single_answer');
