<div class="lesson-next">
    <span><?php echo __('Next', 'sikshya') ?></span>
    <a href="<?php echo esc_url($next_link); ?>"><?php echo esc_html($title); ?></a>
</div>


