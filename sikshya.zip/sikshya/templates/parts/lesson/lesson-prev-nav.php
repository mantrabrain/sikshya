<div class="lesson-prev">
    <span><?php echo __('Prev', 'sikshya') ?></span>
    <a href="<?php echo esc_url($prev_link); ?>"><?php echo esc_html($title); ?></a>
</div>


