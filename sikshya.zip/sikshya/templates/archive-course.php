<?php

sikshya_header();

echo '<div class="sikshya-wrap sikshya-courses-wrap sikshya-container">';

sikshya_load_template('parts.course.archive-content');

echo '</div>';

sikshya_footer();
