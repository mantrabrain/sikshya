<div class="sik-col-md-9">
    <div class="sikshya-account-content-area">
        <?php
        do_action('sikshya_account_content_item')
        ?>
    </div>
</div>