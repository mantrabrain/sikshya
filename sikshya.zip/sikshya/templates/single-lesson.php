<?php

sikshya_header();

sikshya_single_content();

sikshya_footer();
