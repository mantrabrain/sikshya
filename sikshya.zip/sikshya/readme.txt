=== Learning Management System - Sikshya LMS ===
Contributors: Mantrabrain,ughimire1
Tags: course builder, quizzes, questions, learning management system, LMS
Requires at least: 4.7
Tested up to: 5.5.1
Stable tag: 0.0.11
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Sikshya is free Learning management system (LMS) for WordPress. It helps to create course, lessons, quizzes, questions and answers for your online course system.

== Description ==
[Sikshya]( https://mantrabrain.com/downloads/sikshya-wordpress-learning-management-system/?utm_source=wordpress&utm_medium=wppage&utm_campaign=wporg) is free Learning management system (LMS) for WordPress. It helps to create course, lessons, quizzes, questions and answers for your online course system.

Get [free support](https://mantrabrain.com/support-forum/)
Wanna [contribute](https://github.com/mantrabrain/sikshya/)
Feature [request](https://mantrabrain.com/request-new-feature/)

== Installation ==

1. Install the plugin either via the WordPress.org plugin directory, or by uploading the files to your server (in the /wp-content/plugins/ directory).
2. Activate the Mantra Audience plugin through the 'Plugins' menu in WordPress.


== Sikshya - Features ==

1. Unlimited Course with tag and category

2. Unlimited lessons, quizzes and questions

3. Translation Ready: The plugin is fully translation ready. So feel free to your website in any language.


== IMPORTANT LINKS ==

* Plugin page: [Click here](https://mantrabrain.com/downloads/sikshya-wordpress-learning-management-system/?utm_source=wordpress&utm_medium=wppage&utm_campaign=wporg)
* Plugin review/feedback: [Click here](https://wordpress.org/support/plugin/sikshya/reviews/)
* Plugin support/bug report: [Click here](https://mantrabrain.com/support-forum/)

== Changelog ==

= 0.0.11 | 2020/09/23 =
* Fixed - Ordering issue fixed
