<div class="sikshya-actions">
    <a class="js-sikshya__sections-lessons-add button button-primary button-large"
       href="javascript:void(0);">
        <span class="ms-icon ms-icon-lesson"></span>
        <?php _e('Add lesson', 'sikshya'); ?>
    </a>
</div>