<h3 class="js-group__label js-sikshya__sections-item_title ms-head"
    data-default="<?php echo esc_html($title); ?>">
    <span class="js-group__label_text"><?php echo esc_html($title); ?></span>
    <a class="js-sikshya__remove-section" href="#"><span
            class="dashicons dashicons-trash"></span></a>
</h3>