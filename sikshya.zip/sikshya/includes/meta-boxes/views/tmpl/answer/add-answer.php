<div class="sikshya-actions js-sikshya__quiz-question-answers-actions">
    <a class="js-sikshya__quiz-question-answers-add button button-primary button-large"
       href="javascript:void(0);">
        <?php _e('Add answer', 'sikshya'); ?>
    </a>
</div>