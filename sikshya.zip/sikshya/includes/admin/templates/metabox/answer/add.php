<p class="add-answer">
    <button type="button"
            class="button sik-add-question-answer-button"><?php esc_html_e('Add answer', 'sikshya') ?></button>
</p>