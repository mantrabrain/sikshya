<div id="admin-editor-sik_course" class="sik-admin-editor sik-box-data admin-editor-sik-course">
    <div class="sik-box-data-head sik-row">
        <h3 class="heading"><?php echo __('Course Options', 'sikshya') ?></h3>
    </div>
    <div class="sik-box-data-content">
        <div class="sik-box-body-content">
            <div class="sikshya-course-option-container">
                <?php
                do_action('sikshya_course_metaboxes');
                ?>
            </div>
        </div>
    </div>
</div>


