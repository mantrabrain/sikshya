<p class="add-question">
    <button type="button"
            class="button sik-add-question-button"><?php esc_html_e('Add question', 'sikshya') ?></button>
</p>